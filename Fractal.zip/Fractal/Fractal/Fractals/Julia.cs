﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Numerics;
using System.Collections;

namespace Fractal
{
    public class Julia : abstract_fractal
    {
        Panel panel;

        public Julia( Panel f )
        {
            g = f.CreateGraphics();
            panel = f;
        }
        
        private double zoom = 1, moveX = 0, moveY = 0;
        private int w = 400, h = 300;
        private double cRe, cIm;           //real and imaginary part of the constant c, determinate shape of the Julia Set
        private int maxIterations = 100;

        public override void draw()
        {
            MyColor color = new MyColor();
            // Holds all of the possible colors
            Color[] cs = new Color[256];
            // Fills cs with the colors from the current ColorMap file
            cs = GetColors(ColMaps[CurColMap]);
            double newRe, newIm, oldRe, oldIm;   //real and imaginary parts of new and old
            //ColorRGB color; //the RGB color value for the pixel
            Bitmap bp = new Bitmap(w, h);
            int i;
            int r, g, b;
            //pick some values for the constant c, this determines the shape of the Julia Set
            cRe = -0.7;
            cIm = 0.27015;
            //Bitmap bp = new Bitmap(800, 600, System.Drawing.Imaging.PixelFormat.Format24bppRgb);

            //loop through every pixel
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    //calculate the initial real and imaginary part of z, based on the pixel location and zoom and position values
                    newRe = 1.5 * (x - w / 2) / (0.5 * zoom * w) + moveX;
                    newIm = (y - h / 2) / (0.5 * zoom * h) + moveY;
                    //i will represent the number of iterations
                    i = 0;
                    //start the iteration process
                    while (i < maxIterations)
                    {
                        //remember value of previous iteration
                        oldRe = newRe;
                        oldIm = newIm;
                        //the actual iteration, the real and imaginary part are calculated
                        newRe = oldRe * oldRe - oldIm * oldIm + cRe;
                        newIm = 2 * oldRe * oldIm + cIm;
                        //if the point is outside the circle with radius 2: stop
                        if ((newRe * newRe + newIm * newIm) > 4) break;
                        i++;
                    }
                    //use color model conversion to get rainbow palette, make brightness black if maxIterations reached
                    //color = HSVtoRGB(ColorHSV(i % 256, 255, 255 * (i < maxIterations)));
                    //draw the pixel
                    if (i < maxIterations) b = 255; else b = 0;
                    //color.HsvToRgb(i % 256, 255, b, out r, out g, out b);
                    //SolidBrush brush = new SolidBrush(Color.FromArgb(r, g, b));
                    //SolidBrush brush = new SolidBrush(color.HsvToRgb(i % 256, 255, b));
                    //this.g.FillRectangle(brush, x, y, 1, 1);
                    //bp.SetPixel(x, y, color.HsvToRgb(i % 256, 255, b));
                    double perc = i / (100.0);
                    // Get that part of a 255 scale
                    int val = ((int)(perc * 255));
                    // Use that number to set the color
                    bp.SetPixel(x, y, cs[val]);
                }
            }
            panel.BackgroundImage = bp;
        }

        int CurColMap = 13;
        string[] ColMaps = System.IO.Directory.GetFiles(@"c:\C-sharp-projects\MandelC#\COPY ALL THESE FILES TO THE RUN DIR", "*.ColorMap");
        const bool COLOR = false;

        private Color[] GetColors(string Path)
        {
            try
            {
                Color[] c = new Color[256];
                System.IO.StreamReader sr = new System.IO.StreamReader(Path);
                ArrayList lines = new ArrayList();
                string s = sr.ReadLine();
                while (s != null)
                {
                    lines.Add(s);
                    s = sr.ReadLine();
                }
                int i = 0;
                for (i = 0; i < Math.Min(256, lines.Count); i++)
                {
                    string curC = (string)lines[i];
                    Color temp = Color.FromArgb(int.Parse(curC.Split(' ')[0]),
                                                int.Parse(curC.Split(' ')[1]),
                                                int.Parse(curC.Split(' ')[2]));
                    c[i] = temp;
                }
                for (int j = i; j < 256; j++)
                {
                    c[j] = Color.White;
                }
                return c;
            }
            catch (Exception ex)
            {
                throw new Exception("Invalid ColorMap file.", ex);
            }
        }

        public override void decrease()
        {
            zoom /= 2;
            moveX = (4 * mouse_X - 2 * w) / (w * zoom);
            moveY = (2 * h - 4 * mouse_Y) / (h * zoom);
            draw();
        }

        public override void increase()
        {
            zoom *= 2;
            moveX = (4 * mouse_X - 2 * w) / (w* zoom);
            moveY = (2 * h - 4 * mouse_Y) / (h* zoom);
            draw();
        }

        public override void up()
        {
            moveY -= 0.5 / zoom;
            draw();
        }

        public override void down()
        {
            moveY += 0.5 / zoom;
            draw();
        }

        public override void left()
        {
            moveX -= 0.5 / zoom;
            draw();
        }

        public override void right()
        {
            moveX += 0.5 / zoom;
            draw();
        }
    }
}
