﻿using System.Drawing;
using System.Windows.Forms;
using Fractal.Utility;

namespace Fractal
{
    public class Koch_snowflake : abstract_fractal
    {
        private double Koch_depth = 5;
        private Pen pen = new Pen(Color.Green);
        Panel panel;

        
        public Koch_snowflake(Panel f)
        {
            panel = f;
            g = f.CreateGraphics();
            width = f.Width - 2;
            height = f.Height - 2;
            X = 0;
            Y = 0;
        }

        private Point calc_delta(Point p1, Point p2)
        {
            Point d = new Point();
            d = MyPoint.sub(p1, p2);
            d = MyPoint.divide_by_scalar(d, 3);
            return d;
        }

        private Triangle make_first_triangle()
        {
            Triangle triangle;
            triangle.P1 = new Point();
            triangle.P2 = new Point();
            triangle.P3 = new Point();

            triangle.P1.X = (panel.Width / 2) + X;
            triangle.P1.Y = Y;

            triangle.P2.X = triangle.P1.X - (width / 2);
            triangle.P2.Y = triangle.P1.Y + height;

            triangle.P3.X = triangle.P1.X + (width / 2);
            triangle.P3.Y = triangle.P1.Y + height;

            return triangle;
        }

        public override void draw()
        {

        }

        public override void decrease()
        {
        }

        public override void increase()
        {
        }

        public override void left()
        {
        }

        public override void right()
        {
        }

        public override void up()
        {
        }
        
        public override void down()
        {
        }
    }
}
