﻿using System;
using System.Collections;
using System.Drawing;
using System.Windows.Forms;

namespace Fractal
{
    public class Mandelbrot : abstract_fractal
    {
        Panel panel;
        public Mandelbrot( Panel f )
        {
            g = f.CreateGraphics();
            panel = f;
        }

        public override void draw()
        {
            DrawMandel();
            //draw_Mandi();
        }

        private void draw_Mandi()
        {
            MyColor color = new MyColor();
            int w = 400, h = 300;
            int maxIterations = 100;//after how much iterations the function should stop
            int i;
            int r, g, b;
            double x, y, x1, y1, xx, xmin, xmax, ymin, ymax = 0.0;

            Bitmap bp = new Bitmap(w, h);
            double intigralX, intigralY = 0.0;
            xmin = Sx; // Start x value, normally -2.1
            ymin = Sy; // Start y value, normally -1.3
            xmax = Fx; // Finish x value, normally 1
            ymax = Fy; // Finish y value, normally 1.3
            intigralX = (xmax - xmin) / w; // Make it fill the whole window
            intigralY = (ymax - ymin) / h;
            x = xmin;

            //loop through every pixel
            for (int s = 0; s < w; s++)
            {
                y = ymin;
                for (int z = 0; z < h; z++)
                {
                    x1 = 0;
                    y1 = 0;
                    i = 0;
                    //start the iteration process
                    while (i < maxIterations && Math.Sqrt((x1 * x1) + (y1 * y1)) < 2)
                    {
                        i++;
                        xx = (x1 * x1) - (y1 * y1) + x;
                        y1 = 2 * x1 * y1 + y;
                        x1 = xx;
                    }
                    //use color model conversion to get rainbow palette, make brightness black if maxIterations reached
                    if (i < maxIterations) b = 255; else b = 0;
                    color.HsvToRgb(i % 256, 255, b, out r, out g, out b);
                    //SolidBrush brush = new SolidBrush(Color.FromArgb(r, g, b));
                    //this.g.FillRectangle(brush, s, z, 1, 1);
                    bp.SetPixel(s, z, Color.FromArgb(r, g, b));
                    y += intigralY;
                }
                x += intigralX;
            }
            panel.BackgroundImage = bp; // Draw it to the form
        }

        private Color[] GetColors(string Path)
        {
            try
            {
                Color[] c = new Color[256];
                System.IO.StreamReader sr = new System.IO.StreamReader(Path);
                ArrayList lines = new ArrayList();
                string s = sr.ReadLine();
                while (s != null)
                {
                    lines.Add(s);
                    s = sr.ReadLine();
                }
                int i = 0;
                for (i = 0; i < Math.Min(256, lines.Count); i++)
                {
                    string curC = (string)lines[i];
                    Color temp = Color.FromArgb(int.Parse(curC.Split(' ')[0]), 
                                                int.Parse(curC.Split(' ')[1]), 
                                                int.Parse(curC.Split(' ')[2]));
                    c[i] = temp;
                }
                for (int j = i; j < 256; j++)
                {
                    c[j] = Color.White;
                }
                return c;
            }
            catch (Exception ex)
            {
                throw new Exception("Invalid ColorMap file.", ex);
            }
        }

        double Sx = -2.1;
        double Sy = -1.3;
        double Fx = 1;
        double Fy = 1.3;
        Bitmap bq = null;
        Point pStart = Point.Empty;
        Point pFinish = Point.Empty;
        int CurColMap = 5;
        string[] ColMaps = System.IO.Directory.GetFiles(@"c:\C-sharp-projects\MandelC#\COPY ALL THESE FILES TO THE RUN DIR", "*.ColorMap");
        const bool COLOR = false;

        private void DrawMandel()
        {
            // Holds all of the possible colors
            Color[] cs = new Color[256];
            // Fills cs with the colors from the current ColorMap file
            cs = GetColors(ColMaps[CurColMap]);
            // Creates the Bitmap we draw to
            width = 400;
            height = 300;
            Bitmap b = new Bitmap(width, height);
            // From here on out is just converted from the c++ version.
            double x, y, x1, y1, xx, xmin, xmax, ymin, ymax = 0.0;

            int looper, s, z = 0;
            double intigralX, intigralY = 0.0;
            xmin = Sx; // Start x value, normally -2.1
            ymin = Sy; // Start y value, normally -1.3
            xmax = Fx; // Finish x value, normally 1
            ymax = Fy; // Finish y value, normally 1.3
            intigralX = (xmax - xmin) / width; // Make it fill the whole window
            intigralY = (ymax - ymin) / height;
            x = xmin;

            for (s = 1; s < width; s++)
            {
                y = ymin;
                for (z = 1; z < height; z++)
                {
                    x1 = 0;
                    y1 = 0;
                    looper = 0;
                    while (looper < 100 && Math.Sqrt((x1 * x1) + (y1 * y1)) < 2)
                    {
                        looper++;
                        xx = (x1 * x1) - (y1 * y1) + x;
                        y1 = 2 * x1 * y1 + y;
                        x1 = xx;
                    }

                    // Get the percent of where the looper stopped
                    double perc = looper / (100.0);
                    // Get that part of a 255 scale
                    int val = ((int)(perc * 255));
                    // Use that number to set the color
                    b.SetPixel(s, z, cs[val]);
                    y += intigralY;
                }
                x += intigralX;
            }
            bq = b; // bq is a globally defined bitmap
            panel.BackgroundImage = (Image)bq; // Draw it to the form
        }

        public override void decrease()
        {
        }

        public override void increase()
        {
        }

        public override void up()
        {
        }

        public override void down()
        {
        }

        public override void left()
        {
        }

        public override void right()
        {
        }
    }
}
